package in.Elearning.java;

public class ImageResize {

}
