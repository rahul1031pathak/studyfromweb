package in.Elearning.java;

public class ImageReducer {
	
	

}
