package structure.refrence;

import java.util.ArrayList;

public class Article_Ref_Result {
	
	public	ArrayList<Article_Ref_Article> Article_Ref_Article_list=new ArrayList<Article_Ref_Article>();
	public	ArrayList<Article_Ref_Video>Article_Ref_Video_list=new ArrayList<Article_Ref_Video>();
	public	ArrayList<Ques_Ref_Article> Ques_Ref_Article_list=new ArrayList<Ques_Ref_Article>();

	
}
