package structure.refrence;

import java.util.ArrayList;



public class Ques_Ref_Result {
	public	ArrayList<Ques_Ref_Ques> Ques_Ref_Ques_list=new ArrayList<Ques_Ref_Ques>();
	public	ArrayList<Ques_Ref_Article> Ques_Ref_Article_list=new ArrayList<Ques_Ref_Article>();
	public	ArrayList<Ques_Ref_Video> Ques_Ref_Video_list=new ArrayList<Ques_Ref_Video>();
	
}
