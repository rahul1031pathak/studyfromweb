package structure.refrence;

import java.util.ArrayList;

public class Video_Ref_Result {
	
	public	ArrayList<Video_Ref_Video>Video_Ref_Video_list=new ArrayList<Video_Ref_Video>();
	public	ArrayList<Ques_Ref_Video> Ques_Ref_Video_list=new ArrayList<Ques_Ref_Video>();
	public	ArrayList<Article_Ref_Video> Article_Ref_Video_list=new ArrayList<Article_Ref_Video>();
}
