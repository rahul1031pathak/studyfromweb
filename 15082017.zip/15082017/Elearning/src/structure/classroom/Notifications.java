package structure.classroom;

import java.util.ArrayList;

public class Notifications {

	public ArrayList<Notification> notifications=new ArrayList<Notification>();
}
