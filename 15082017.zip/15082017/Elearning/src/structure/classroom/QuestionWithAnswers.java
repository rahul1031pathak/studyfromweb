package structure.classroom;

import java.util.ArrayList;

public class QuestionWithAnswers {
	public ArrayList<Dao_Answer> answerList=new ArrayList<Dao_Answer>();
	public Question question;
}
