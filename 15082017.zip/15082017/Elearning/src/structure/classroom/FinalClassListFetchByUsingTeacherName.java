package structure.classroom;

import java.util.ArrayList;

public class FinalClassListFetchByUsingTeacherName {
	
	public String teacher_id;
	public String teacher_name;
	public	ArrayList<ClassroomDetails> classdetails=new ArrayList<ClassroomDetails>();



}
