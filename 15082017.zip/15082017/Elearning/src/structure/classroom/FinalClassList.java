package structure.classroom;

import java.util.ArrayList;

import structure.user.UserSearch;



public class FinalClassList {
	public	ArrayList<UserSearch> userlistSearch=new ArrayList<UserSearch>();
public	ArrayList<FinalClassListFetchByUsingTeacherName> classdetailsWithTeacherId=new ArrayList <FinalClassListFetchByUsingTeacherName>();


}
