package structure.user;

import java.util.ArrayList;

public class Member {
public	ArrayList<MembershipReq> membershipReqlist;
	public ArrayList<AlreadyMember> alreadyMember;
	public ArrayList<AlreadyMember> alreadySubscribed;

}
