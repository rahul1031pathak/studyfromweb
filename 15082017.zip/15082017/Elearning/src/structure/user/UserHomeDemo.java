package structure.user;

import java.util.ArrayList;

public class UserHomeDemo {
	public User user;
	public ArrayList<AlreadyMember> alreadyMember=new ArrayList<AlreadyMember>();
	
	public ArrayList<AlreadyMember> subscribed=new ArrayList<AlreadyMember>();
	public ArrayList<User_Class_Details > createdClassroomList=new ArrayList<User_Class_Details >();
}
