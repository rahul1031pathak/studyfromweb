package structure.user;

import java.util.ArrayList;

public class UserList {
	public	ArrayList<User> userlist=new ArrayList<User>();

}
