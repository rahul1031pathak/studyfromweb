$("document").ready(function(){
	$(".login_form input[type=text]").hide();
});